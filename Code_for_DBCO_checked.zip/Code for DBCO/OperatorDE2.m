function [Offspring] = OperatorDE2(Problem,Population,Population_previous,Frame_index)
    % Calculate subrank based on objective values
    PopulationObj = tiedrank(Population.objs);
    PopulationObj_previous = tiedrank(Population_previous.objs);
    
    % Set neighborhood size based on Qiu xin's paper published on TEVC in 2015
    D = size(Population(1).decs,2);
    if Problem.M == 2
        T = 5;
    elseif Problem.M >= 3
        T = 15;
    end
    
    % different framework use different method
    if Frame_index == 0
        % dominance framework
        trial = zeros(Problem.N,D);
        for i = 1:Problem.N
            Individual = PopulationObj(i,:);
            
            if rand() < 0.5
                Dist_current = pdist2(Individual,PopulationObj);
                [~,Neighbour_current] = sort(Dist_current,2);
                Neighbour_current = Neighbour_current(:,2:T+1);
                
                Dist_previous = pdist2(Individual,PopulationObj_previous);
                [~,Neighbour_previous] = sort(Dist_previous,2);
                Neighbour_previous = Neighbour_previous(:,1:T);
                
                R1 = randsample(T,1);
                R1 = Neighbour_current(R1);
                R2 = randsample(T,1);
                R2 = Neighbour_previous(R2);
            else
                R1 = randsample(length(Population),1);
                R2 = randsample(length(Population_previous),1);
            end
            
            l = rand;
            if l <= 1/3
                F = 0.6;
            elseif l <= 2/3
                F = 0.8;
            else
                F = 1.0;
            end
            
            l = rand;
            if l <= 1/3
                CR = 0.1;
            elseif l <= 2/3
                CR = 0.2;
            else
                CR = 1.0;
            end
            
            V = Population(R1).decs + F*(Population(R1).decs - Population_previous(R2).decs);
            Lower = Problem.lower;
            Upper = Problem.upper;
            V = min(max(V,Lower),Upper);
            
            Position = rand(1,D) < CR;
            jrand = randperm(D,1);
            Position(jrand) = 1;
            Opposite = 1 - Position;
            trial(i,:) = Position.*V + Opposite.*Population(i).decs;
        end
    else
        % decomposition framework
        trial = zeros(1,D);
        Individual = PopulationObj(Frame_index,:);
        
        if rand() < 0.5
            Dist_current = pdist2(Individual,PopulationObj);
            [~,Neighbour_current] = sort(Dist_current,2);
            Neighbour_current = Neighbour_current(:,2:T+1);
            
            Dist_previous = pdist2(Individual,PopulationObj_previous);
            [~,Neighbour_previous] = sort(Dist_previous,2);
            Neighbour_previous = Neighbour_previous(:,1:T);
            
            R1 = randsample(T,1);
            R1 = Neighbour_current(R1);
            R2 = randsample(T,1);
            R2 = Neighbour_previous(R2);
        else
            R1 = randsample(length(Population),1);
            R2 = randsample(length(Population_previous),1);
        end
        
        l = rand;
        if l <= 1/3
            F = 0.6;
        elseif l <= 2/3
            F = 0.8;
        else
            F = 1.0;
        end
        
        l = rand;
        if l <= 1/3
            CR = 0.1;
        elseif l <= 2/3
            CR = 0.2;
        else
            CR = 1.0;
        end
        
        V = Population(R1).decs + F*(Population(R1).decs - Population_previous(R2).decs);
        Lower = Problem.lower;
        Upper = Problem.upper;
        V = min(max(V,Lower),Upper);
        
        Position = rand(1,D) < CR;
        jrand = randperm(D,1);
        Position(jrand) = 1;
        Opposite = 1 - Position;
        trial = Position.*V + Opposite.*Population(Frame_index).decs;
    end
    
    Offspring = trial;
    Offspring = Problem.Evaluation(Offspring);
end