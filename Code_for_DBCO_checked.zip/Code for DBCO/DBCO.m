classdef DBCO < ALGORITHM
% <multi> <real/integer/label/binary/permutation> <constrained>
% Dual-Stage Bidirectional Coevolution for Constrained Multiobjective
% Optimization

%------------------------------- Reference --------------------------------
% Y. Tian, T. Zhang, J. Xiao, X. Zhang, and Y. Jin, A coevolutionary
% framework for constrained multi-objective optimization problems, IEEE
% Transactions on Evolutionary Computation, 2021, 25(1): 102-116.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2023 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    methods
        function main(Algorithm,Problem)
            %% Initialization
            % SF1 for stage I of Population 1, SF2 for stage I of Population 2
            [SF1, SF2] = Algorithm.ParameterSet(0.3, 0.2);
            
            % Initialization of Population 1
            [W, Problem.N] = UniformPoint(Problem.N, Problem.M);
            T  = ceil(Problem.N/10);
            nr = 2;
            B  = pdist2(W, W);
            [~,B] = sort(B,2);
            B  = B(:, 1:T);
            Population1 = Problem.Initialization();
            Z = min(Population1.objs,[],1);
            Pop1_pre = [];
            
            % Initialization of Population 2
            Population2 = Problem.Initialization();
            Fitness2 = CalFitness(-Population2.objs);
            Pop2_pre = [];
            
            % Initialization of Archive (for output) and archive (for Population 2 in stage-transition)
            Archive = EnvironmentalSelection2([Population1,Population2],Problem.N);
            archive = EnvironmentalSelection2(Population2,Problem.N);
            
            % Initialization of stage index
            Flag1 = false;
            Flag2 = false;
            H     = 0;
            
            %% Main Loop
            while Algorithm.NotTerminated(Population1)
                % Reproduction of Population 2: Population 2 generate Offspring 2
                if isempty(Pop2_pre)
                    MatePool2  = TournamentSelection(2,2*Problem.N,Fitness2);
                    Offspring2 = OperatorDE(Problem,Population2,Population2(MatePool2(1:(end/2))),Population2(MatePool2((end/2)+1:end)));
                else
                    if rand < 0.5
                        MatePool2  = TournamentSelection(2,2*Problem.N,Fitness2);
                        Offspring2 = OperatorDE(Problem,Population2,Population2(MatePool2(1:(end/2))),Population2(MatePool2((end/2)+1:end)));
                    else
                        Offspring2 = OperatorDE2(Problem,Population2,Pop2_pre,0);
                    end
                end
                Pop2_pre = Population2;
                Z = min([Z;Offspring2.objs],[],1);
                
                % Transfer Offspring 2 knowledge to Population 1
                Pop1_temp = Population1;
                for i = 1:length(Offspring2)
                    [~,Associate] = min(acos(1- pdist2(Offspring2(i).objs,W,'cosine')));
                    if rand < 0.9
                        P = B(Associate,randperm(size(B,2)));
                    else
                        P = randperm(Problem.N);
                    end
                    Z = min(Z,Offspring2(i).obj);
                    if ~Flag1
                        % Stage I
                        g_old = max(abs(Population1(P).objs-repmat(Z,length(P),1))./W(P,:),[],2);
                        g_new = max(repmat(abs(Offspring2(i).obj-Z),length(P),1)./W(P,:),[],2);
                        Population1(P(find( g_new <= g_old,nr))) = Offspring2(i);
                    else
                        % Stage II
                        Angold = acos(1-pdist2((Population1.objs-repmat(Z,Problem.N,1)),W,'cosine'));
                        [~,Associate_old] = min(Angold,[],2);
                        Angnew = acos(1-pdist2((Offspring2(i).objs-Z),W,'cosine'));
                        [~,Associate_new] = min(Angnew,[],2);
                        CV_old = overall_cv(Population1.cons);
                        CV_new = overall_cv(Offspring2(i).cons);
                        cnt = 0;
                        for k = 1:size(P,2)
                            y = any(Offspring2(i).objs<Population1(P(k)).objs)-any(Offspring2(i).objs>Population1(P(k)).objs);
                            if Associate_old(P(k)) == P(k) && Associate_new == P(k)
                                if CV_new < CV_old(P(k))
                                    Population1(P(k)) = Offspring2(i);
                                    cnt = cnt + 1;
                                else
                                    if CV_new == CV_old(P(k)) && y == 1
                                        Population1(P(k)) = Offspring2(i);
                                        cnt = cnt + 1;
                                    elseif CV_new == CV_old(P(k)) && y == 0
                                        newpop = [Population1,Offspring2(i)];
                                        CrowdDis1 = CrowdingDistance(newpop.objs);
                                        if CrowdDis1(P(k)) < CrowdDis1(end)
                                            Population1(P(k)) = Offspring2(i);
                                            cnt = cnt + 1;
                                        end
                                    end
                                end
                            elseif Associate_old(P(k)) == P(k)
                                a = 1;
                            elseif Associate_new == P(k)
                                Population1(P(k)) = Offspring2(i);
                                cnt = cnt + 1;
                            else
                                Ang_old = rad2deg(acos(1-pdist2((Population1(P(k)).objs-Z),W(P(k),:),'cosine')));
                                Ang_new = rad2deg(acos(1-pdist2((Offspring2(i).objs-Z),W(P(k),:),'cosine')));
                                if Ang_new < Ang_old && CV_new < CV_old(P(k))
                                    Population1(P(k)) = Offspring2(i);
                                    cnt = cnt + 1;
                                else
                                    if Ang_new < Ang_old && CV_new == CV_old(P(k)) && y == 1
                                        Population1(P(k)) = Offspring2(i);
                                        cnt = cnt + 1;
                                    elseif Ang_new < Ang_old && CV_new == CV_old(P(k)) && y == 0
                                        newpop = [Population1,Offspring2(i)];
                                        CrowdDis1 = CrowdingDistance(newpop.objs);
                                        if CrowdDis1(P(k)) < CrowdDis1(end)
                                            Population1(P(k)) = Offspring2(i);
                                            cnt = cnt + 1;
                                        end
                                    end
                                end
                            end
                            if cnt == nr
                                break
                            end
                        end
                    end
                end
                
                % Reproduction and environmental selection of Population 1: Population 1 generate Offspring 1 and update itself
                Offspring1 = Population1;
                for i = 1:Problem.N
                    if rand < 0.9
                        P = B(i,randperm(size(B,2)));
                    else
                        P = randperm(Problem.N);
                    end
                    if isempty(Pop1_pre)
                        Offspring = OperatorDE(Problem,Population1(i),Population1(P(1)),Population1(P(2)));
                    else
                        if rand < 0.5
                            Offspring = OperatorDE(Problem,Population1(i),Population1(P(1)),Population1(P(2)));
                        else
                            Offspring = OperatorDE2(Problem,Population1,Pop1_pre,i);
                        end
                    end
                    Offspring1(i) = Offspring;
                    Z = min(Z,Offspring.obj);
                    if ~Flag1
                        g_old = max(abs(Population1(P).objs-repmat(Z,length(P),1))./W(P,:),[],2);
                        g_new = max(repmat(abs(Offspring.obj-Z),length(P),1)./W(P,:),[],2);
                        Population1(P(find( g_new <= g_old,nr))) = Offspring;
                        if Problem.FE > SF1*Problem.maxFE
                            Flag1 = true;
                        end
                    else
                        if H == 0 % P-to-lambda mapping
                           H = 1;
                           Angle = acos(1-pdist2(W,(Population1.objs-repmat(Z,Problem.N,1)),'cosine'));
                           [~,associate] = min(Angle,[],2);
                           Population1   = Population1(associate);
                        end
                        Angold = acos(1-pdist2((Population1.objs-repmat(Z,Problem.N,1)),W,'cosine'));
                        [~,Associate_old] = min(Angold,[],2);
                        Angnew = acos(1-pdist2((Offspring.objs-Z),W,'cosine'));
                        [~,Associate_new] = min(Angnew,[],2);
                        CV_old = overall_cv(Population1.cons);
                        CV_new = overall_cv(Offspring.cons);
                        cnt = 0;
                        for k = 1:size(P,2)
                            y = any(Offspring.objs<Population1(P(k)).objs)-any(Offspring.objs>Population1(P(k)).objs); % y = 1: the offspring dominates the parent
                            if Associate_old(P(k)) == P(k) && Associate_new == P(k)
                                if CV_new < CV_old(P(k))
                                    Population1(P(k)) = Offspring;
                                    cnt = cnt + 1;
                                else
                                    if CV_new == CV_old(P(k)) && y == 1
                                        Population1(P(k)) = Offspring;
                                        cnt = cnt + 1;
                                    elseif CV_new == CV_old(P(k)) && y == 0
                                        newpop = [Population1,Offspring];
                                        CrowdDis1 = CrowdingDistance(newpop.objs);
                                        if CrowdDis1(P(k)) < CrowdDis1(end)
                                            Population1(P(k)) = Offspring;
                                            cnt = cnt + 1;
                                        end
                                    end
                                end
                            elseif Associate_old(P(k)) == P(k)
                                a = 1;
                            elseif Associate_new == P(k)
                                Population1(P(k)) = Offspring;
                                cnt = cnt + 1;
                            else
                                Ang_old = rad2deg(acos(1-pdist2((Population1(P(k)).objs-Z),W(P(k),:),'cosine')));
                                Ang_new = rad2deg(acos(1-pdist2((Offspring.objs-Z),W(P(k),:),'cosine')));
                                if Ang_new < Ang_old && CV_new < CV_old(P(k))
                                    Population1(P(k)) = Offspring;
                                    cnt = cnt + 1;
                                else
                                    if Ang_new < Ang_old && CV_new == CV_old(P(k)) && y == 1
                                        Population1(P(k)) = Offspring;
                                        cnt = cnt + 1;
                                    elseif Ang_new < Ang_old && CV_new == CV_old(P(k)) && y == 0
                                        newpop = [Population1,Offspring];
                                        CrowdDis1 = CrowdingDistance(newpop.objs);
                                        if CrowdDis1(P(k)) < CrowdDis1(end)
                                            Population1(P(k)) = Offspring;
                                            cnt = cnt + 1;
                                        end
                                    end
                                end
                            end
                            if cnt == nr
                               break 
                            end
                        end
                    end
                end
                Pop1_pre = Pop1_temp;
                
                % Environmental selection of Population 2: Population 2 update itself with Population 2, Offspring 1, and Offspring 2
                if ~Flag2
                    [Population2,Fitness2] = EnvironmentalSelection1([Population2,Offspring2,Offspring1],Problem);
                    archive = EnvironmentalSelection2([archive,Offspring2],Problem.N);
                    if Problem.FE > SF2*Problem.maxFE
                        Flag2 = true;
                        Population2 = archive;
                        Fitness2    = CalFitness(Population2.objs,Population2.cons);
                    end
                else
                    [Population2,Fitness2] = EnvironmentalSelection2([Population2,Offspring2,Offspring1],Problem.N);
                end
                
                % Environmental selection of Archive: Archive update itself with Archive, Offspring 1, and Offspring 2
                Archive = EnvironmentalSelection2([Archive,Offspring1,Offspring2],Problem.N);
                if Problem.FE >= Problem.maxFE
                    Population1 = Archive;
                end
            end
        end
    end
end

function result = overall_cv(cv)
	cv(cv <= 0) = 0;cv = abs(cv);   
	result = sum(cv,2);            
end